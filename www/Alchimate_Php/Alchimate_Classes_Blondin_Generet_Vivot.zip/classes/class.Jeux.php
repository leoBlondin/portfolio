<?php
require_once('class.Niveau.php');
require_once('class.Poste.php');
class Jeux
{

    private $id = 0;
    private $nom = null;
    private $description = null;
    private $parution = null;

    private $leNiveau = null;
    private $lePoste = null;


    /* constructers */
    public function __construct($id, $nom, $description, $parution)
    {
        $this->id = $id;
        $this->nom = $nom;
        $this->description = $description;
        $this->parution = $parution;
    }


    /* getters */
    public function getId()                         {return $this->id;}
    public function getNom()                        {return $this->nom;}
    public function getDescription()                {return $this->description;}
    public function getParution()                   {return $this->parution;}

    public function getLeNiveau()                   {return $this->leNiveau;}
    public function getLePoste()                    {return $this->lePoste;}

    /* setters */
    public function setId($id)                      {$this->id = $id;}
    public function setNom($nom)                    {$this->nom = $nom;}
    public function setDescription($description)    {$this->description = $description;}
    public function setParution($parution)          {$this->parution = $parution;}

    public function setLeNiveau($leNiveau)          {$this->leNiveau = $leNiveau;}
    public function setLePoste($lePoste)            {$this->lePoste = $lePoste;}

}

?>