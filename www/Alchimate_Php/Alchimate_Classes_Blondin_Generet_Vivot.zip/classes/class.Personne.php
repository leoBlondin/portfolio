<?php

require_once('class.Graduation.php');
require_once('class.Niveau.php');
require_once('class.Poste.php');
require_once('class.Region.php');
require_once('class.Equipe.php');


class Personne{

    private $id_Personne = 0;
    private $nom = null;
    private $prenom = null;
    private $naissanceDate = null;
    private $sexe = null;
    private $pseudo = null;
    private $description = null;
    private $mail = null;
    private $login = null;
    private $password = null;
    private $image = null;
    private $commentaire = null;

    private $laGraduation = null;
    private $leNiveau = null;
    private $lePoste = null;
    private $laRegion = null;
    private $lEquipe = null;


    /* constructers */
    public function __construct($id_Personne, $nom, $prenom, $naissanceDate, $sexe, $pseudo, $description, $mail, $login, $password, $image, $commentaire)
    {
        $this->id_Personne = $id_Personne;
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->naissanceDate = $naissanceDate;
        $this->sexe = $sexe;
        $this->pseudo = $pseudo;
        $this->description = $description;
        $this->mail = $mail;
        $this->login = $login;
        $this->password = $password;
        $this->image = $image;
        $this->commentaire = $commentaire;
    }


    /* getters */
    public function getIdPersonne()                             {return $this->id_Personne;}
    public function getNom()                                    {return $this->nom;}
    public function getPrenom()                                 {return $this->prenom;}
    public function getNaissanceDate()                          {return $this->naissanceDate;}
    public function getSexe()                                   {return $this->sexe;}
    public function getPseudo()                                 {return $this->pseudo;}
    public function getDescription()                            {return $this->description;}
    public function getMail()                                   {return $this->mail;}
    public function getLogin()                                  {return $this->login;}
    public function getPassword()                               {return $this->password;}
    public function getImage()                                  {return $this->image;}
    public function getCommentaire()                            {return $this->commentaire;}

    public function getLaGraduation()                           {return $this->laGraduation;}
    public function getLeNiveau()                               {return $this->leNiveau;}
    public function getLePoste()                                {return $this->lePoste;}
    public function getLaRegion()                               {return $this->laRegion;}
    public function getLEquipe()                                {return $this->lEquipe;}


    /* setters */
    public function setIdPersonne($id_Personne)                 {$this->id_Personne = $id_Personne;}
    public function setNom($nom)                                {$this->nom = $nom;}
    public function setPrenom($prenom)                          {$this->prenom = $prenom;}
    public function setNaissanceDate($naissanceDate)            {$this->naissanceDate = $naissanceDate;}
    public function setSexe($sexe)                              {$this->sexe = $sexe;}
    public function setPseudo($pseudo)                          {$this->pseudo = $pseudo;}
    public function setDescription($description)                {$this->description = $description;}
    public function setMail($mail)                              {$this->mail = $mail;}
    public function setLogin($login)                            {$this->login = $login;}
    public function setPassword($password)                      {$this->password = $password;}
    public function setImage($image)                            {$this->image = $image;}
    public function setCommentaire($commentaire)                {$this->commentaire = $commentaire;}

    public function setLaGraduation($laGraduation)              {$this->laGraduation = $laGraduation;}
    public function setLeNiveau($leNiveau)                      {$this->leNiveau = $leNiveau;}
    public function setLePoste($lePoste)                        {$this->lePoste = $lePoste;}
    public function setLaRegion($laRegion)                      {$this->laRegion = $laRegion;}
    public function setLEquipe($lEquipe)                        {$this->lEquipe = $lEquipe;}

}

?>